package com.mycompany.a3laticinios;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Menu extends javax.swing.JFrame {
   
    public Menu() {
        initComponents();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jButtonVendas = new javax.swing.JButton();
        jButtonCliente = new javax.swing.JButton();
        jButtonConsulta = new javax.swing.JButton();
        jButtonLogout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonVendas.setText("Vendas");
        jButtonVendas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButtonVendasActionPerformed(evt);
            }
        });

        jButtonCliente.setText("Cliente");
        jButtonCliente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButtonClienteActionPerformed(evt);
            }
        });

        jButtonConsulta.setText("Consulta");
        jButtonConsulta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButtonConsultaActionPerformed(evt);
            }
        });

        jButtonLogout.setText("Logout");
        jButtonLogout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButtonLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(151, 151, 151)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonVendas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonConsulta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(169, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jButtonVendas)
                .addGap(18, 18, 18)
                .addComponent(jButtonCliente)
                .addGap(18, 18, 18)
                .addComponent(jButtonConsulta)
                .addGap(18, 18, 18)
                .addComponent(jButtonLogout)
                .addContainerGap(97, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }
    
    

    private void jButtonVendasActionPerformed(java.awt.event.ActionEvent evt) {
    Vendas vendasScreen = new Vendas(); // Cria uma nova instância da classe Vendas
    vendasScreen.setVisible(true); // Exibe a tela de vendas

    this.setVisible(false);

    }

    private void jButtonClienteActionPerformed(java.awt.event.ActionEvent evt) {
          Clientes clientesScreen = new Clientes(); // Cria uma nova instância da classe Vendas
    clientesScreen.setVisible(true); // Exibe a tela de vendas

 
    this.setVisible(false);
    }

    private void jButtonConsultaActionPerformed(java.awt.event.ActionEvent evt) {
              Consultas consultasScreen = new Consultas(); // Cria uma nova instância da classe Vendas
    consultasScreen.setVisible(true); // Exibe a tela de consultas

  
    this.setVisible(false);
    }

    private void jButtonLogoutActionPerformed(java.awt.event.ActionEvent evt) {
        A3Laticinios loginScreen = new A3Laticinios();
        loginScreen.setVisible(true);
        loginScreen.setTitle("Login");

        // Close the current menu screen
        this.dispose();

        JOptionPane.showMessageDialog(this, "Logout realizado com sucesso");
    }
   
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    private javax.swing.JButton jButtonCliente;
    private javax.swing.JButton jButtonConsulta;
    private javax.swing.JButton jButtonLogout;
    private javax.swing.JButton jButtonVendas;
    private javax.swing.JPanel jPanel1;
}
