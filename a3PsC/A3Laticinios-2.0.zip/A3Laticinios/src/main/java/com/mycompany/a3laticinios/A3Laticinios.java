
package com.mycompany.a3laticinios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.BoxLayout;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JLabel;


public class A3Laticinios extends javax.swing.JFrame {

    public A3Laticinios() {
        initComponents();
    }
    
   String imagePath = "/logo.png";
   ImageIcon logoIcon = new ImageIcon(getClass().getResource(imagePath));

   
 
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        JLabel logoLabel = new JLabel(logoIcon);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        
       jPanel1.setLayout(new BoxLayout(jPanel1, BoxLayout.Y_AXIS));
       jPanel1.add(logoLabel);
       logoLabel.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);



        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });

        jButton1.setText("Login");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });

        jButton2.setText("New User");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newUserButtonActionPerformed(evt);
            }
        });

        jLabel1.setText("Usuário");

        jLabel2.setText("Senha");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(169, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2))
                    .addComponent(jPasswordField1, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(129, 129, 129))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(100, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(99, 99, 99))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(37, 37, 37))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30))
        );

        pack();
    }

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO: Add any custom handling for the "Usuário" field if needed
    }

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO: Add any custom handling for the "Senha" field if needed
    }

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {
        String username = jTextField1.getText();
        String password = String.valueOf(jPasswordField1.getPassword());

        if (authenticate(username, password)) {
            // Login successful, establish database connection
            connectToDatabase();
            // Perform desired actions or open new screen
            Menu menu;
            menu = new Menu();
            menu.setVisible(true);
            
            System.out.println("Login successful");
        } else {
            // Authentication failed, display error message
            System.out.println("Invalid username or password");
        }
    }

    private void newUserButtonActionPerformed(java.awt.event.ActionEvent evt) {
        String username = jTextField1.getText();
        String password = String.valueOf(jPasswordField1.getPassword());

         if (username.isEmpty() || password.isEmpty()) {
        // Exibir uma mensagem de alerta se algum dos campos estiver vazio
        JOptionPane.showMessageDialog(this, "Por favor, preencha ambos os campos.", "Alerta", JOptionPane.WARNING_MESSAGE);
    } else 
        
        if (createUser(username, password)) {
            System.out.println("Novo usuário criado com sucesso: " + username);


            // Close current login screen if needed
            this.dispose();

            // Exibir uma mensagem para o usuário informando que o novo usuário foi criado com sucesso
            JOptionPane.showMessageDialog(this, "Novo usuário criado com sucesso: " + username);
            
             // Criar uma nova instância da tela de login
            A3Laticinios loginScreen = new A3Laticinios();
            loginScreen.setVisible(true);

            // Fechar a tela atual de cadastro de usuário
            this.dispose();
            
        } else {
            System.out.println("Erro ao criar novo usuário");
            // Exibir uma mensagem de erro caso ocorra algum problema ao criar o novo usuário
            JOptionPane.showMessageDialog(this, "Erro ao criar novo usuário", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean createUser(String username, String password) {
        try {
            // Estabelecer conexão com o banco de dados SQLite
            Connection connection = DriverManager.getConnection("jdbc:sqlite:users.db");

            // Verificar se o usuário já existe no banco de dados
            String query = "SELECT * FROM users WHERE username = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
 if (username.isEmpty() || password.isEmpty()) {
        // Exibir uma mensagem de alerta se algum dos campos estiver vazio
        JOptionPane.showMessageDialog(this, "Por favor, preencha ambos os campos.", "Alerta", JOptionPane.WARNING_MESSAGE);
    } else 
            // Se o usuário já existe, retornar falso e exibir uma mensagem de erro
            if (resultSet.next()) {
                System.out.println("Usuário já existe: " + username);
                return false;
            }

            // Inserir o novo usuário no banco de dados
            String insertQuery = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
            insertStatement.setString(1, username);
            insertStatement.setString(2, password);
            int rowsAffected = insertStatement.executeUpdate();

            // Verificar se o novo usuário foi criado com sucesso
            if (rowsAffected > 0) {
                // Fechar recursos
                resultSet.close();
                statement.close();
                insertStatement.close();
                connection.close();
                return true;
            } else {
                System.out.println("Erro ao criar novo usuário");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Erro ao criar novo usuário: " + e.getMessage());
            return false;
        }
    }

    public void connectToDatabase() {
        try {
            // Carregando o driver JDBC para o SQLite
            Class.forName("org.sqlite.JDBC");

            // Estabelecendo a conexão com o banco de dados SQLite
            String url = "jdbc:sqlite:users.db";
            connection = DriverManager.getConnection(url);
            System.out.println("Conexão com o banco de dados estabelecida.");
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver JDBC não encontrado: " + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("Erro ao conectar ao banco de dados: " + ex.getMessage());
        }
    }

    private boolean authenticate(String username, String password) {
        try {
            // Estabelecer conexão com o banco de dados SQLite
            Connection connection = DriverManager.getConnection("jdbc:sqlite:users.db");

            // Consultar o banco de dados para verificar as credenciais
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            // Verificar se o usuário e senha correspondem
            boolean authenticated = resultSet.next();
            System.out.println("Authenticated: " + authenticated);

            // Fechar recursos
            resultSet.close();
            statement.close();
            connection.close();

            return authenticated;
        } catch (SQLException e) {
            System.err.println("Erro ao autenticar o usuário: " + e.getMessage());
            return false;
        }
    }
    
    

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new A3Laticinios().setVisible(true);
            }
        });
    }

    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JPasswordField jPasswordField1;
    private Connection connection;
}